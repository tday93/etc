pub const SYS_perf_event_open: ::c_long = 319;
