A simple map based on a vector for small integer keys.

Documentation is available at https://contain-rs.github.io/vec-map/vec_map.
