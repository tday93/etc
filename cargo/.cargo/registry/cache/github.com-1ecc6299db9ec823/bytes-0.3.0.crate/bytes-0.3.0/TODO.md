
# TODO

* Implement growable byte buf
* Implement chained byte buf
* Support size hint on Source
* Better result error semantics for buf
