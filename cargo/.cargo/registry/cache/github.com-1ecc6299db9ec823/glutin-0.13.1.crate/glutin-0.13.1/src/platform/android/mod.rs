#![cfg(target_os = "android")]

pub use winit::EventsLoop;

pub use api::android::*;
