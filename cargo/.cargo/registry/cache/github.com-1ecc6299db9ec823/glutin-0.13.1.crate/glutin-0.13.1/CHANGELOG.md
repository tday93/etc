# Unreleased

# Version 0.13.1 (2018-03-07)

- Fix android activity life cycle
- Update winit dependency to 0.11.2

# Version 0.13.0 (2018-02-28)

- Update winit dependency to 0.11.1

# Version 0.12.2 (2018-02-12)

- Don't use yanked version of winit

# Version 0.12.1 (2018-02-05)

- Add support for winapi 0.3 ([#975](https://github.com/tomaka/glutin/pull/975))
- Fix MacOS to return compatibility profile if applicable (#[977](https://github.com/tomaka/glutin/pull/977))
- Update gl_generator and macos dependencies
