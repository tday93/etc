# wayland-kbd
Keyboard utilities for the wayland-client library. Mainly handling keymaps with the help of libxkbcommon.

# Documentation

Available on [docs.rs](https://docs.rs/wayland-kbd/)

Documentation for the master branch is also hosted on
https://smithay.github.io/wayland-kbd
