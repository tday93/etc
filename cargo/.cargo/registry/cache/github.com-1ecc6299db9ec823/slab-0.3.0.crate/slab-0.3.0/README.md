Slab Allocator for Rust

Preallocate memory for values of a given type.
