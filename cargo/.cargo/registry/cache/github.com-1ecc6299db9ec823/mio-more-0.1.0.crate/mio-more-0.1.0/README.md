# Mio More

Extra components for use with Mio.

## Maintenance status

This repository is not actively maintained. It is mostly a dumping ground of
code that was deprecated in the Mio crate.

## TODO

* Move the tests over from the mio repository

# License

`tokio-more` is primarily distributed under the terms of both the MIT license
and the Apache License (Version 2.0), with portions covered by various BSD-like
licenses.

See LICENSE-APACHE, and LICENSE-MIT for details.
