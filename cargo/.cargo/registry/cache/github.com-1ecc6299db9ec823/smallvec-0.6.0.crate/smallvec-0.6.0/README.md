rust-smallvec
=============

[Documentation](http://docs.rs/smallvec/)

[Release notes](https://github.com/servo/rust-smallvec/releases)

"Small vector" optimization for Rust: store up to a small number of items on the stack
