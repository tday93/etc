# approx

[![Build Status](https://travis-ci.org/brendanzab/approx.svg?branch=master)](https://travis-ci.org/brendanzab/approx)
[![Version](https://img.shields.io/crates/v/approx.svg)](https://crates.io/crates/approx)
[![License](https://img.shields.io/crates/l/approx.svg)](https://github.com/brendanzab/approx/blob/master/LICENSE)
[![Downloads](https://img.shields.io/crates/d/approx.svg)](https://crates.io/crates/approx)

[Documentation](http://brendanzab.github.io/approx)

Approximate floating point equality comparisons and assertions.
