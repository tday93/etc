pub use self::any_arg::{AnyArg, DispOrder};
pub use self::arg::Arg;
pub use self::arg_builder::{Base, Switched, Valued, FlagBuilder, OptBuilder, PosBuilder};
pub use self::arg_matcher::ArgMatcher;
pub use self::arg_matches::{Values, OsValues, ArgMatches};
pub use self::group::ArgGroup;
pub use self::matched_arg::MatchedArg;
pub use self::settings::{ArgFlags, ArgSettings};
pub use self::subcommand::SubCommand;

#[macro_use]
mod macros;
mod arg;
pub mod any_arg;
mod arg_matches;
mod arg_matcher;
mod subcommand;
mod arg_builder;
mod matched_arg;
mod group;
pub mod settings;

#[doc(hidden)]
#[derive(Copy, Clone, Debug)]
pub enum ArgKind {
    Flag,
    Opt,
    Pos,
    Subcmd,
    Group,
}
