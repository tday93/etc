import logging

logging.warning('Deprecated: sleekxmpp.xmlstream.jid is moving to sleekxmpp.jid')

from sleekxmpp.jid import JID
