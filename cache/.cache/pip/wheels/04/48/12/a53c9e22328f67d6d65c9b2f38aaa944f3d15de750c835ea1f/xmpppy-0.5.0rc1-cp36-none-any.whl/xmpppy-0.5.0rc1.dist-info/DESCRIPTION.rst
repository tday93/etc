This library provides functionality for writing xmpp-compliant
clients, servers and/or components/transports.

It was initially designed as a "rework" of the jabberpy library but
has become a separate product.

Unlike jabberpy it is distributed under the terms of GPL.

