
This package is used to launch an application built using JupyterLab


